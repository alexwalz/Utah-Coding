* **Files**

  * `07-HandlebarsAnimalsBase`

* **Instructions**

  * You will edit the `server.js` file, the `dog.handlebars` file, and the `index.handlebars` file in an attempt to recreate the application that we demonstrated just a couple of minutes ago. Instructions on what to do are contained within each file you will have to edit.

  * You won't be using MySQL for this exercise but will instead be using the animals array in the `server.js` file.
