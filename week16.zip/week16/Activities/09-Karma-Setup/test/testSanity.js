var expect = require("chai").expect;

describe("Universe", function() {
  it("should be self-consistent", function() {
    expect(2).to.equal(2);
  });
});
