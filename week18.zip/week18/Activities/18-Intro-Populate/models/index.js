// Exporting an object containing all of our models

module.exports = {
  Book: require("./Book"),
  Library: require("./Library")
};
