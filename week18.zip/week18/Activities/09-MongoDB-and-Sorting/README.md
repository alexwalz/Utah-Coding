# MongoDB & Sorting

## Instructions

Make four routes that display results from your zoo collection:

1. Root: Displays a simple "Hello World" message (no mongo required).
2. All: Send JSON response with all animals.
3. Name: Send JSON response sorted by name in ascending order.
4. Weight: Send JSON response sorted by weight in descending order.
