# Custom Methods

## Instructions

1. Go to userModel.js, and create custom methods
  based on the details offered in the file.

2. Once you've made those custom methods, use them
  in this file's POST request

3. Good luck!
